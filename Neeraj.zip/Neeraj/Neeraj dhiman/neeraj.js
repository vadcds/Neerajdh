let a = neeraj
console.log("a")